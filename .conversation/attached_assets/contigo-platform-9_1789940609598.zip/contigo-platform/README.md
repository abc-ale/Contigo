# Contigo

Plataforma Spring Boot 3 / Java 21 con arquitectura MVC, JWT, PostgreSQL Supabase y frontend Tailwind. Incluye el ciclo Solicitud → asignación → check-in/out geolocalizado → seguimiento → evaluación.

## Inicio

1. Crea un proyecto Supabase y un bucket **privado** `contigo-media`; ejecuta `supabase-setup.sql` en SQL Editor.
2. Copia `.env.example` a variables de entorno reales. No versionar secretos.
3. `mvn spring-boot:run` y abre `http://localhost:8080`.

## Guía completa para ejecutar en Windows

### 1. Instalar requisitos

- Java 21 (verificar con `java -version`).
- Maven 3.9+ (verificar con `mvn -version`).
- Una cuenta y proyecto en Supabase.

### 2. Configurar Supabase

1. En Supabase, crea un proyecto y espera a que esté disponible.
2. Abre **SQL Editor** y ejecuta `supabase-setup.sql` para crear el bucket privado `contigo-media`.
3. En **Connect**, copia la cadena PostgreSQL URI/JDBC y la contraseña de la base de datos.
4. En **Settings > API**, copia el **Project URL** y la clave `service_role`. Esta clave solo se usa en backend.

### 3. Configurar enlaces y claves

Abre `src/main/resources/application.properties` y reemplaza los valores `TU_PROJECT_REF`, `PEGA_AQUI_LA_SERVICE_ROLE_KEY` y `PEGA_AQUI_EL_TOKEN_FACTILIZA`. Alternativamente, en PowerShell define variables antes de iniciar:

```powershell
$env:SUPABASE_DB_URL="jdbc:postgresql://db.TU_PROJECT_REF.supabase.co:5432/postgres?sslmode=require"
$env:SUPABASE_DB_USER="postgres"
$env:SUPABASE_DB_PASSWORD="tu_password"
$env:SUPABASE_URL="https://TU_PROJECT_REF.supabase.co"
$env:SUPABASE_SERVICE_ROLE_KEY="tu_service_role_key"
$env:FACTILIZA_BASE_URL="https://api.factiliza.com"
$env:FACTILIZA_TOKEN="tu_token_factiliza"
$env:JWT_SECRET="una-clave-larga-aleatoria-de-al-menos-32-caracteres"
```

Para Factiliza, confirma en su consola la ruta contratada. Si difiere, define `FACTILIZA_DNI_PATH`; `%s` representa el DNI que el backend inserta automáticamente.

### 4. Arrancar

Desde la carpeta `contigo-platform`, ejecuta:

```powershell
mvn clean spring-boot:run
```

Abre `http://localhost:8080`. Flyway aplicará automáticamente el DDL sobre la base configurada. Para empaquetar: `mvn clean package`; el JAR queda en `target/` y puede iniciarse con `java -jar target/contigo-api-1.0.0.jar`.

### 5. Primera cuenta

Registra una cuenta mediante `POST /api/v1/auth/register` antes de iniciar sesión. Ejemplo JSON:

```json
{"email":"familiar@contigo.pe","password":"ClaveSegura123!","role":"CLIENTE_DECISOR","fullName":"Ana Pérez","phone":"999999999","dni":"12345678"}
```

Flyway aplica el DDL en `src/main/resources/db/migration/V1__contigo_schema.sql`. Para Supabase use el connection string de la pestaña **Connect** con SSL. El usuario de BD y la service role key son únicamente del servidor. Todos los enlaces y secretos externos están centralizados en `src/main/resources/application.properties`, con sustitución por variables de entorno.

## Diseño MVC

`ViewController` entrega las vistas Thymeleaf: `login`, `dashboard`, `booking` y `tracking`. `OperationsController`, `AuthController`, `FileController` e `IdentityController` son la capa Controller REST; las entidades y repositorios forman el Model. Las vistas consumen esa API autenticada con JWT y son responsive, con navegación móvil.

## Estructura de carpetas

```text
src/main/java/pe/contigo/api/
├── config/                 # Spring Security y JWT
├── controller/             # Vistas MVC y endpoints REST
├── domain/
│   ├── entity/             # Una entidad JPA por archivo
│   └── enums/              # Roles y estados del negocio
├── repository/             # Un repositorio por archivo
└── service/                # Lógica de Supabase y negocio
```

## API

`POST /api/v1/auth/register`, `POST /api/v1/auth/login`; pasar `Authorization: Bearer <jwt>` para el resto. La API de DNI es `GET /api/v1/identity/dni/{8 digitos}` y se consume durante la reserva desde el navegador. El endpoint/forma exacta puede variar según el plan de Factiliza: configure `FACTILIZA_BASE_URL` y `FACTILIZA_DNI_PATH` con lo provisto en su consola.

`POST /api/v1/files/upload` recibe multipart `file` y `category=profile|evidence`; acepta JPG/PNG/WEBP (<5MB) y almacena en Supabase Storage privado. Guarde el `objectKey` en `profile_photo_url` o `evidence_photo_url`; use `GET /api/v1/files/signed-url?objectKey=...` para presentar una URL temporal.
