package pe.contigo.api.dto;
import jakarta.validation.constraints.*;
public record ReviewRequest(@Min(1) @Max(5) short rating, String comment) {}
