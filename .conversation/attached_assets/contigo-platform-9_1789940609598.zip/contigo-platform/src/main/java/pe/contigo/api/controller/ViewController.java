package pe.contigo.api.controller;
import org.springframework.stereotype.Controller; import org.springframework.web.bind.annotation.GetMapping;
@Controller public class ViewController { @GetMapping({"/","/login"}) public String login(){return "login";} @GetMapping("/registro") public String registro(){return "registro";} @GetMapping("/dashboard") public String dashboard(){return "dashboard";} @GetMapping("/solicitar") public String booking(){return "booking";} @GetMapping("/seguimiento") public String tracking(){return "tracking";} }
