package pe.contigo.api.dto;
import jakarta.validation.constraints.*; import pe.contigo.api.domain.enums.ServiceType; import java.time.Instant; import java.util.UUID;
public record BookingRequest(@NotNull UUID seniorPersonId, @NotNull ServiceType serviceType, @NotNull Instant scheduledTime, @DecimalMin("0.5") double durationHours, @NotBlank String pickupAddress, String destinationAddress, String notes) {}
