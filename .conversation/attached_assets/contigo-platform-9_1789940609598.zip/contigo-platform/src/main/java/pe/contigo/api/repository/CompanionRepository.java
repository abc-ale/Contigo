package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.CompanionProfile; import pe.contigo.api.domain.enums.CompanionStatus; import java.util.*;
public interface CompanionRepository extends JpaRepository<CompanionProfile,UUID>{List<CompanionProfile> findByStatusAndBackgroundChecked(CompanionStatus s,boolean b);}
