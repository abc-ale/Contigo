package pe.contigo.api.dto;
import jakarta.validation.constraints.NotNull; import java.util.UUID;
public record AssignmentRequest(@NotNull UUID companionId) {}
