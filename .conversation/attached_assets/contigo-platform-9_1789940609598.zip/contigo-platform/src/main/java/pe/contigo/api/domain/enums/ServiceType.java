package pe.contigo.api.domain.enums;
public enum ServiceType { CITA_MEDICA, TRAMITE, COMPRAS, TECNOLOGIA, RECREACION }
