package pe.contigo.api.domain.enums;
public enum CompanionStatus { DISPONIBLE, EN_SERVICIO, INACTIVO }
