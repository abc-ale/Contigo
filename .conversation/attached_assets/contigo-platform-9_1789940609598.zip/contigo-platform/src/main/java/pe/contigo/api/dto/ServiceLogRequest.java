package pe.contigo.api.dto;
import jakarta.validation.constraints.NotNull; import pe.contigo.api.domain.enums.EventType;
public record ServiceLogRequest(@NotNull EventType eventType, Double latitude, Double longitude, String detail) {}
