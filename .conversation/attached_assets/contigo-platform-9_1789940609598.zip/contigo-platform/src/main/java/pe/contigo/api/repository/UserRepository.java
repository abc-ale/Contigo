package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.AppUser; import java.util.*;
public interface UserRepository extends JpaRepository<AppUser,UUID>{Optional<AppUser> findByEmail(String email);}
