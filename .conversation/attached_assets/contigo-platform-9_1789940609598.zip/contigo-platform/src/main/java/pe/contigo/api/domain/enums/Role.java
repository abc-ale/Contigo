package pe.contigo.api.domain.enums;
public enum Role { CLIENTE_DECISOR, PERSONAL_ACOMPANANTE, ADMINISTRADOR }
