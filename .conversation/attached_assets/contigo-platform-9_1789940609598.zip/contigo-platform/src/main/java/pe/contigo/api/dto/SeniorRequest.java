package pe.contigo.api.dto;
import jakarta.validation.constraints.*;
public record SeniorRequest(@NotBlank String fullName, @Min(60) short age, String medicalNotes, String emergencyContact) {}
