package pe.contigo.api.domain.enums;
public enum EventType { CHECK_IN, CHECK_OUT, INCIDENTE, ESTADO }
