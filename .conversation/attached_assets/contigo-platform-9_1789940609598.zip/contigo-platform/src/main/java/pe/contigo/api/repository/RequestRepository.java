package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.ServiceRequest; import java.util.*;
public interface RequestRepository extends JpaRepository<ServiceRequest,UUID>{List<ServiceRequest> findByDecisorIdOrderByScheduledTimeDesc(UUID id);List<ServiceRequest> findByCompanionUserIdOrderByScheduledTimeAsc(UUID id);}
