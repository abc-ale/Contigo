package pe.contigo.api.dto;
import jakarta.validation.constraints.*; import pe.contigo.api.domain.enums.Role;
public record RegisterRequest(@Email @NotBlank String email, @NotBlank String password, @NotNull Role role, @NotBlank String fullName, String phone, @Pattern(regexp="\\d{8}") String dni) {}
