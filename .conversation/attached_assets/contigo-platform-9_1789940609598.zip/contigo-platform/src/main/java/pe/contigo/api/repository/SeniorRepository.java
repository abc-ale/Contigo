package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.SeniorPerson; import java.util.*;
public interface SeniorRepository extends JpaRepository<SeniorPerson,UUID>{List<SeniorPerson> findByDecisorId(UUID id);}
