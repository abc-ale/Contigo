package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.Review; import java.util.*;
public interface ReviewRepository extends JpaRepository<Review,UUID>{boolean existsByServiceRequestId(UUID id);}
