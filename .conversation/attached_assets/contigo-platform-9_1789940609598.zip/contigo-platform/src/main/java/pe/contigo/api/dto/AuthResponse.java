package pe.contigo.api.dto;
public record AuthResponse(String token, String role, String fullName) {}
