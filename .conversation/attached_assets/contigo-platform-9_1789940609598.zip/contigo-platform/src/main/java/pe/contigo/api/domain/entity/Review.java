package pe.contigo.api.domain.entity;
import jakarta.persistence.*; import java.time.Instant; import java.util.UUID;
@Entity @Table(name="reviews") public class Review { @Id @GeneratedValue private UUID id; @OneToOne(optional=false) @JoinColumn(name="service_request_id") private ServiceRequest serviceRequest; private short rating; @Column(columnDefinition="text") private String comment; private Instant createdAt=Instant.now(); public void setServiceRequest(ServiceRequest v){serviceRequest=v;} public void setRating(short v){rating=v;} public void setComment(String v){comment=v;} }
