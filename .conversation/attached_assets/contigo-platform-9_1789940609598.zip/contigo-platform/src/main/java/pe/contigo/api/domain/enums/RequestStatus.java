package pe.contigo.api.domain.enums;
public enum RequestStatus { SOLICITADO, ASIGNADO, EN_CURSO, FINALIZADO, CANCELADO }
