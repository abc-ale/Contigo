package pe.contigo.api;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class ContigoApplication { public static void main(String[] args){SpringApplication.run(ContigoApplication.class,args);} }
