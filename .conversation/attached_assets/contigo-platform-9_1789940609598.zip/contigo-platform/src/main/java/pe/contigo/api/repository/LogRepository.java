package pe.contigo.api.repository;
import org.springframework.data.jpa.repository.JpaRepository; import pe.contigo.api.domain.entity.ServiceLog; import java.util.*;
public interface LogRepository extends JpaRepository<ServiceLog,UUID>{List<ServiceLog> findByServiceRequestIdOrderByTimestampAsc(UUID id);}
