-- Ejecutar en Supabase SQL Editor. El esquema de aplicación es creado por Flyway.
-- Crear el bucket privado desde Storage > New bucket: contigo-media (no público).
-- O por SQL, si el rol tiene privilegios:
insert into storage.buckets (id, name, public) values ('contigo-media','contigo-media', false) on conflict (id) do nothing;
-- Las imágenes se acceden solamente por URL firmada generada en backend. No crear políticas públicas.
